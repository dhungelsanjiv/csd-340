
public class Practice {
    public static void main(String arg[]) {
        int x = 32;
        double y = 36.75;

        System.out.println("x mod 10 = " + x % 10);// 2
        System.out.println("y mod 10 = " + y % 10);// 6.75

    }
}